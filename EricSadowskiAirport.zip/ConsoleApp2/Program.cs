﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace air
{
    class Program
    {
        static List<Airport> AirportsList = new List<Airport>();

        private static void Main(string[] args)
        {
            try
            {
                ReadAllDataFromFile();
                CallMenu();

            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine(ex.Message);
            }

            while (true)
            {
                string input = Console.ReadLine();

                // Execute the command
                ExecuteCommand(input);
            }

        }


        static void ReadAllDataFromFile()
        {

            //Create object of FileInfo for specified path            
            FileInfo fi = new FileInfo(@"..\..\..\data.txt");

            //Open file for Read\Write
            FileStream fs = fi.Open(FileMode.OpenOrCreate, FileAccess.Read, FileShare.Read);

            //Create object of StreamReader by passing FileStream object on which it needs to operates on
            StreamReader sr = new StreamReader(fs);


            while (!sr.EndOfStream)
            {
                string thisLine = sr.ReadLine();
                string[] info = thisLine.Split(new string[] { ";" }, StringSplitOptions.None);
                AddAirportData(info[0], double.Parse(info[2]), double.Parse(info[3]), int.Parse(info[4]), info[1]);
            }

            //Close StreamReader object after operation
            sr.Close();
            fs.Close();


        }

        private static void AddAirportData(string code, double lat, double lng, int elevM, string city)
        {
            Airport newPort = new Airport(code, lat, lng, elevM, city);
            AirportsList.Add(newPort);
        }

        private static void CallMenu()
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("1. Add Airport");
            Console.WriteLine("2. List all airports");
            Console.WriteLine("3. Find nearest airport by code");
            Console.WriteLine("4. Find airport's elevation standard deviation");
            Console.WriteLine("5. Change log delegates");
            Console.WriteLine("0. Exit");
            Console.WriteLine("Enter your choice:");

        }

        private static void ListAllAirportsInfo()
        {
            foreach (var airport in AirportsList)
            {
                Console.WriteLine(airport.ToString());
            }
        }

        private static void FindAirportByCode(string search)
        {
            search = search.ToUpper();
            var matchingAirports = AirportsList.Where(airport => airport.Code.Equals(search));

            foreach (var airport in matchingAirports)
            {
                Console.WriteLine(airport.Code);
            }
        }

        //static void FindPersonYoungerThan(int age)
        //{
        //    foreach (var person in people)
        //    {
        //        if (person.Age < age)
        //        {
        //            Console.WriteLine(person.Name + ", Age: " + person.Age);
        //        }
        //    }
        //}

        static void ExecuteCommand(string command)
        {
            switch (command)
            {
                case "0":
                    Save();
                    Environment.Exit(0);
                    break;
                case "1":
                    Console.WriteLine("Enter code");
                    string code = Console.ReadLine();
                    Console.WriteLine("Enter latitude");
                    double lat = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter longitude");
                    double lng = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter elevation meters");
                    int elevM = int.Parse(Console.ReadLine());
                    Console.WriteLine("Enter city");
                    string city = Console.ReadLine();
                   
                    AddAirportData(code,lat,lng,elevM, city);
                    CallMenu();
                    break;
                case "2":
                    ListAllAirportsInfo();
                    CallMenu();
                    break;
                case "3":
                    Console.WriteLine("Enter code to search");
                    string input = Console.ReadLine();
                    FindAirportByCode(input);
                    CallMenu();
                    break;
                case "4":
                  //  Console.WriteLine("Enter maximum age");
                   // int input2 = int.Parse(Console.ReadLine());
                   // FindPersonYoungerThan(input2);
                    CallMenu();
                    break;
                default:
                    Console.WriteLine("Invalid command");
                    CallMenu();
                    break;
            }
        }

        static void Save()
        {
            using (StreamWriter writer = new StreamWriter(@"..\..\..\data.txt"))
            {
                foreach (var airport in AirportsList)
                {
                    writer.WriteLine($"{airport.Code};{airport.City};{airport.Latitude};{airport.Longitude};{airport.ElevM}");
                }
            }
        }
    }
}