﻿using System.Text.RegularExpressions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace air
{
     class Airport
    {

        
		private string _code; //fields private
        private double _lat;
        private double _lng;
        private int _elevM;

        private string _city;

        public Airport(string code, double lat, double lng, int elevM, string city)
        {
            Code = code;
            Latitude = lat;
            Longitude = lng;
            ElevM = elevM;
            City = city;
        }


        public string Code
        {
            get { return _code; }
            set
            {
                string pattern = @"^[A-Z]{3}$";

                if (!Regex.IsMatch(value, pattern))
                {
                    throw new ArgumentException("Code must be 3 uppercase letters");
                }

                _code = value;
            }
        }
        public double Latitude
        {
            get { return _lat; }
            set
            {
                if (value < -90 || value > 90)
                {
                    throw new ArgumentException("Invalid Latitude");
                }
                _lat = value;
            }
        }

        public double Longitude
        {
            get { return _lng; }
            set
            {
                if (value < -180 || value > 180)
                {
                    throw new ArgumentException("Invalid Longitude");
                }
                _lng = value;
            }
        }

        public string City
        {
            get { return _city; }
            set
            {
                if (value.Length < 1 || value.Length > 50)
                {
                    throw new ArgumentException("city must be between 1 and 50 chars");
                }
                _city = value;
            }
        }

        public int ElevM
        {
            get { return _elevM; }
            set
            {
                if (value < -1000 || value > 1000)
                {
                    throw new ArgumentException("Invalid Elevation Meters");
                }
                _elevM = value;
            }
        }


        public override string ToString()
        {
            return $"Airport: Code={Code}, Latitude={Latitude}, Longitude={Longitude}, Elevation Meters={ElevM}, City={City}";
        }



    }
}
