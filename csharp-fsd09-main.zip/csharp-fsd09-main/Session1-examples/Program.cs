﻿using System;



namespace Session1_examples //package
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string message = "test";
            //System.out.println
            Console.WriteLine("Hello world " + message);

            Console.ReadKey();
        }
    }
}
