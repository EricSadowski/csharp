﻿using Microsoft.Win32;
using OwnerCars.Domain;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OwnerCars
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public byte[] ImageData { get; private set; }
        public MainWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            lvOwners.SelectedItem = -1;
            tbName.Text = string.Empty;
            ImagePreview.Source = null;
            idBox.Content = "";

            // Retrieve owners with associated cars and count the number of cars for each owner
            List<Owner> owners = Global.context.owners.Include("Cars").ToList();
            foreach (Owner owner in owners)
            {
                owner.TotalCars = owner.Cars.Count;
            }

            lvOwners.ItemsSource = owners;
            lvOwners.Items.Refresh();
            btnDelete.IsEnabled = false;
            btnUpdate.IsEnabled = false;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            string name = tbName.Text;
            byte[] img = ImageData;
            

            Owner owner = new Owner { Name = name, Image = img};
            Global.context.owners.Add(owner);
            Global.context.SaveChanges();

            LoadData();

        }

        private void UploadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png) | *.jpg; *.jpeg; *.png";

            if (openFileDialog.ShowDialog() == true)
            {
                // Read the binary data of the selected image file
                ImageData = File.ReadAllBytes(openFileDialog.FileName);

                // Display the selected image in the Image element
                ImagePreview.Source = new BitmapImage(new Uri(openFileDialog.FileName));
            }
        }


            public static ImageSource GetImage(byte[] imageData)
            {
                if (imageData == null || imageData.Length == 0)
                    return null;

                var imageSource = new BitmapImage();
                using (var stream = new MemoryStream(imageData))
                {
                    imageSource.BeginInit();
                    imageSource.CacheOption = BitmapCacheOption.OnLoad;
                    imageSource.StreamSource = stream;
                    imageSource.EndInit();
                    imageSource.Freeze();
                }

                return imageSource;
            }
        

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            Owner ownerToBeDeleted = (Owner)lvOwners.SelectedItem;

            Global.context.owners.Remove(ownerToBeDeleted);
            Global.context.SaveChanges();
            LoadData();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            Owner ownerUpdate = (Owner)lvOwners.SelectedItem;
            ownerUpdate.Name = tbName.Text;
            ownerUpdate.Image = ImageData;


            Global.context.SaveChanges();

            LoadData();
        }

        private void btnManage_Click(object sender, RoutedEventArgs e)
        {
            if (lvOwners.SelectedIndex == -1)
            {
                return;
            }
            Owner owner = (Owner)lvOwners.SelectedItem;
            CarManager carGarage = new CarManager(owner);
            carGarage.Owner = this;

            bool? result = carGarage.ShowDialog();
            if (result == true)
            {
                LoadData();
                
            }
            LoadData();
        }

        private void lvOwners_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            if (lvOwners.SelectedIndex == -1)
            {
                return;
            }

            Owner owner = (Owner)lvOwners.SelectedItem;
            tbName.Text = owner.Name;
            //slDifficulty.Value = (int)slDifficulty.Value;
            ImageData = owner.Image;
            ImagePreview.Source = GetImage(ImageData);
            idBox.Content = owner.Id;



            btnDelete.IsEnabled = true;
            btnUpdate.IsEnabled = true;

        }
    }
}
